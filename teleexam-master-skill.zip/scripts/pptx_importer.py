#!/usr/bin/env python3
"""Extract slide text from a course .pptx deck without third-party packages."""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

DRAWING_NS = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
SLIDE_PATTERN = re.compile(r"^ppt/slides/slide(\d+)\.xml$")

# Zero-width / invisible Unicode characters to strip from extracted text.
_ZERO_WIDTH_RE = re.compile(
    "["
    "\u200b-\u200f"
    "\u2028\u2029"
    "\u2060"
    "\ufeff"
    "\u00ad"
    "]"
)


# AIGC watermark marker lines to filter from extracted text.
_AIGC_WATERMARKS = {"AI生成"}
_AIGC_WATERMARK_PREFIXES = ("生成时间:", "生成时间：")


def _is_watermark(text: str) -> bool:
    """Check if a line is an AIGC watermark marker."""
    if text in _AIGC_WATERMARKS:
        return True
    return any(text.startswith(prefix) for prefix in _AIGC_WATERMARK_PREFIXES)


def _paragraphs(xml: bytes) -> list[str]:
    root = ET.fromstring(xml)
    paragraphs: list[str] = []
    for paragraph in root.iter(f"{DRAWING_NS}p"):
        text = "".join(node.text or "" for node in paragraph.iter(f"{DRAWING_NS}t")).strip()
        text = _ZERO_WIDTH_RE.sub("", text)
        if text and not _is_watermark(text):
            paragraphs.append(text)
    return paragraphs


def extract_pptx(path: Path) -> list[dict[str, object]]:
    """Return ordered slides with a lightweight title and visible paragraph text."""
    if path.suffix.lower() != ".pptx":
        raise ValueError("目前仅支持 .pptx 文件。请先在 PowerPoint 中将旧版 .ppt 另存为 .pptx。")

    try:
        archive = zipfile.ZipFile(path)
    except zipfile.BadZipFile as error:
        raise ValueError("文件不是有效的 PPTX 演示文稿。") from error

    with archive:
        members = sorted(
            ((int(match.group(1)), name) for name in archive.namelist() if (match := SLIDE_PATTERN.match(name))),
            key=lambda item: item[0],
        )
        if not members:
            raise ValueError("PPTX 中未找到可读取的幻灯片内容。")
        slides: list[dict[str, object]] = []
        for number, name in members:
            paragraphs = _paragraphs(archive.read(name))
            title = paragraphs[0] if paragraphs else f"第 {number} 页（无可提取文字）"
            body = paragraphs[1:] if len(paragraphs) > 1 else []
            slides.append({"number": number, "title": title, "paragraphs": body})
    return slides


def to_markdown(source: Path, slides: list[dict[str, object]]) -> str:
    lines = [f"# PPTX 导入结果：{source.name}", "", f"已读取 {len(slides)} 页幻灯片。", ""]
    for slide in slides:
        lines.append(f"## 第 {slide['number']} 页：{slide['title']}")
        paragraphs = slide["paragraphs"]
        if paragraphs:
            lines.extend(f"- {paragraph}" for paragraph in paragraphs)
        else:
            lines.append("- （本页未提取到正文文字）")
        lines.append("")
    return "\n".join(lines)


def _ensure_utf8_stdout() -> None:
    """Force UTF-8 on stdout/stderr so output never crashes on GBK terminals."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def main() -> None:
    _ensure_utf8_stdout()
    parser = argparse.ArgumentParser(description="提取课程 PPTX 的幻灯片文字，供星辰期末高效通分析。")
    parser.add_argument("input", type=Path, help="课程 .pptx 文件")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument("--output", type=Path, help="可选输出文件；默认打印到终端")
    args = parser.parse_args()

    try:
        slides = extract_pptx(args.input)
    except FileNotFoundError:
        parser.error(f"找不到输入文件：{args.input}")
    except ValueError as error:
        parser.error(str(error))

    result = (
        json.dumps({"source": args.input.name, "slide_count": len(slides), "slides": slides}, ensure_ascii=False, indent=2)
        if args.format == "json"
        else to_markdown(args.input, slides)
    )
    if args.output:
        args.output.write_text(result + "\n", encoding="utf-8")
    else:
        print(result)


if __name__ == "__main__":
    main()
