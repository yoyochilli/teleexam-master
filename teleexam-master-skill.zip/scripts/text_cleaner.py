#!/usr/bin/env python3
"""Clean study notes and split them into headings, bullets, and questions."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Iterable

# Zero-width and invisible Unicode characters injected by AIGC watermarks
# or copied from rich-text sources; must be stripped before processing.
_ZERO_WIDTH_RE = re.compile(
    "["
    "\u200b-\u200f"  # ZWSP, ZWNJ, ZWJ, LTR mark, RTL mark
    "\u2028\u2029"   # line/paragraph separator
    "\u2060"         # word joiner
    "\ufeff"         # BOM / zero-width no-break space
    "\u00ad"         # soft hyphen
    "]"
)

# Trailing AIGC watermark marker line
_AIGC_WATERMARK = "AI生成"

QUESTION = re.compile(r"^(?:第?\s*\d+\s*[题、.．]|[(（]\s*\d+\s*[）)]|\d+\s*[、.．])\s*(.*)$")
HEADING = re.compile(r"^(?:#{1,6}\s+|第[一二三四五六七八九十\d]+[章节]|[一二三四五六七八九十]+[、.])\s*(.+)$")


def strip_zero_width(text: str) -> str:
    """Remove zero-width / invisible Unicode characters from text."""
    return _ZERO_WIDTH_RE.sub("", text)


def normalize_lines(text: str) -> list[str]:
    """Normalize whitespace, strip zero-width chars, and filter AIGC watermarks."""
    text = strip_zero_width(text)
    substitutions = str.maketrans({"：": ":", "；": ";", "，": ",", "（": "(", "）": ")", "　": " "})
    lines: list[str] = []
    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = re.sub(r"[ \t]+", " ", raw.translate(substitutions)).strip()
        if line and line != _AIGC_WATERMARK:
            lines.append(line)
    return lines


def classify(line: str) -> tuple[str, str]:
    if match := QUESTION.match(line):
        return "question", match.group(1).strip() or line
    if match := HEADING.match(line):
        return "heading", match.group(1).strip()
    if line.startswith(("-", "*", "•")):
        return "bullet", line.lstrip("-*• ").strip()
    return "note", line


def build_units(lines: Iterable[str]) -> list[dict[str, object]]:
    units: list[dict[str, object]] = []
    current: dict[str, object] | None = None
    for line in lines:
        kind, content = classify(line)
        if kind == "heading":
            current = {"title": content, "items": []}
            units.append(current)
            continue
        if current is None:
            current = {"title": "未归类材料", "items": []}
            units.append(current)
        current["items"].append({"type": kind, "text": content})
    return units


def render_markdown(source: Path, units: list[dict[str, object]]) -> str:
    output = [f"# 清洗结果：{source.name}", "", f"学习单元：{len(units)} 个", ""]
    for index, unit in enumerate(units, 1):
        output.append(f"## {index}. {unit['title']}")
        for item in unit["items"]:
            label = {"question": "题目", "bullet": "要点", "note": "笔记"}[item["type"]]
            output.append(f"- **{label}**：{item['text']}")
        output.append("")
    return "\n".join(output)


def _ensure_utf8_stdout() -> None:
    """Force UTF-8 on stdout/stderr so output never crashes on GBK terminals."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


def main() -> None:
    _ensure_utf8_stdout()
    parser = argparse.ArgumentParser(description="清洗期末笔记与真题文本。")
    parser.add_argument("input", type=Path, help="UTF-8 文本文件路径")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    parser.add_argument("--output", type=Path, help="可选输出文件；默认打印到终端")
    args = parser.parse_args()

    try:
        raw = args.input.read_text(encoding="utf-8-sig")
    except FileNotFoundError as error:
        parser.error(f"找不到输入文件：{error.filename}")
    except UnicodeDecodeError:
        parser.error("请将输入文件保存为 UTF-8 编码后重试。")

    units = build_units(normalize_lines(raw))
    payload = {"source": args.input.name, "unit_count": len(units), "units": units}
    result = json.dumps(payload, ensure_ascii=False, indent=2) if args.format == "json" else render_markdown(args.input, units)
    if args.output:
        args.output.write_text(result + "\n", encoding="utf-8")
    else:
        print(result)


if __name__ == "__main__":
    main()
